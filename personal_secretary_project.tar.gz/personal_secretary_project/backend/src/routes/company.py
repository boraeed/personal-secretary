from flask import Blueprint, request, jsonify
from src.models.company import Company, Reminder, Action, db
from datetime import datetime

company_bp = Blueprint('company', __name__)

# Routes للشركات
@company_bp.route('/companies', methods=['GET'])
def get_companies():
    try:
        companies = Company.query.all()
        return jsonify([company.to_dict() for company in companies])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@company_bp.route('/companies', methods=['POST'])
def create_company():
    try:
        data = request.get_json()
        
        company = Company(
            name=data.get('name'),
            commercial_register=data.get('commercial_register'),
            contact_person=data.get('contact_person'),
            phone=data.get('phone'),
            email=data.get('email'),
            address=data.get('address'),
            status=data.get('status', 'pending')
        )
        
        db.session.add(company)
        db.session.commit()
        
        return jsonify(company.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@company_bp.route('/companies/<int:company_id>', methods=['GET'])
def get_company(company_id):
    try:
        company = Company.query.get_or_404(company_id)
        return jsonify(company.to_dict())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@company_bp.route('/companies/<int:company_id>', methods=['PUT'])
def update_company(company_id):
    try:
        company = Company.query.get_or_404(company_id)
        data = request.get_json()
        
        company.name = data.get('name', company.name)
        company.commercial_register = data.get('commercial_register', company.commercial_register)
        company.contact_person = data.get('contact_person', company.contact_person)
        company.phone = data.get('phone', company.phone)
        company.email = data.get('email', company.email)
        company.address = data.get('address', company.address)
        company.status = data.get('status', company.status)
        company.updated_at = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify(company.to_dict())
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@company_bp.route('/companies/<int:company_id>', methods=['DELETE'])
def delete_company(company_id):
    try:
        company = Company.query.get_or_404(company_id)
        db.session.delete(company)
        db.session.commit()
        
        return jsonify({'message': 'Company deleted successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

# Routes للتذكيرات
@company_bp.route('/reminders', methods=['GET'])
def get_reminders():
    try:
        reminders = Reminder.query.all()
        return jsonify([reminder.to_dict() for reminder in reminders])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@company_bp.route('/companies/<int:company_id>/reminders', methods=['GET'])
def get_company_reminders(company_id):
    try:
        reminders = Reminder.query.filter_by(company_id=company_id).all()
        return jsonify([reminder.to_dict() for reminder in reminders])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@company_bp.route('/companies/<int:company_id>/reminders', methods=['POST'])
def create_reminder(company_id):
    try:
        data = request.get_json()
        
        reminder = Reminder(
            title=data.get('title'),
            description=data.get('description'),
            reminder_type=data.get('reminder_type'),
            reminder_date=datetime.fromisoformat(data.get('reminder_date')),
            company_id=company_id
        )
        
        db.session.add(reminder)
        db.session.commit()
        
        return jsonify(reminder.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

# Routes للإجراءات
@company_bp.route('/companies/<int:company_id>/actions', methods=['GET'])
def get_company_actions(company_id):
    try:
        actions = Action.query.filter_by(company_id=company_id).order_by(Action.action_date.desc()).all()
        return jsonify([action.to_dict() for action in actions])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@company_bp.route('/companies/<int:company_id>/actions', methods=['POST'])
def create_action(company_id):
    try:
        data = request.get_json()
        
        action = Action(
            title=data.get('title'),
            description=data.get('description'),
            action_type=data.get('action_type', 'call'),
            company_id=company_id
        )
        
        db.session.add(action)
        db.session.commit()
        
        return jsonify(action.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

# Route للإحصائيات
@company_bp.route('/stats', methods=['GET'])
def get_stats():
    try:
        total_companies = Company.query.count()
        pending_reminders = Reminder.query.filter_by(is_completed=False).count()
        completed_companies = Company.query.filter_by(status='completed').count()
        
        return jsonify({
            'total_companies': total_companies,
            'pending_reminders': pending_reminders,
            'completed_companies': completed_companies
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

